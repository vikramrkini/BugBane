Release names
=============

Verifies that the most recent release name has been added to ``./github/RELEASE_NAMES.yml``
